#include <cstdlib>
#include <ctime>
#include <iostream>
#include <string>
class Point {
private:
  long long point = 0;
  bool isDoublePoint = false;

public:
  void trueDoublePoint() {
    isDoublePoint = true;
    std::cout << "You have purchased Double Points!" << std::endl;
  }
  void backdoor() {
    long long value;
    std::cout << "[DEV MODE ACTIVATED]";
    std::cin >> value;
    point = value;
  }
  void Nightmare() {
    point = 0;
    for (point; point > -9999; point -= 99) {
      std::cout << "[NIGHTMARE MODE ACTIVATED] " << point << std::endl;
    }
    std::cout << "28617" << std::endl;
    exit(0);
  }
  long long getPoint() { return point; }
  void accumulatePoints(int newPoint) {
    if (newPoint > 0 && isDoublePoint == true) {
      point += newPoint * 2;
    } else {
      point += newPoint;
    }
  }
};
Point pointObj;
class Unit {
private:
  const int bear_ratio = 30;
  const int wolf_ratio = 15;

public:
  void bear(std::string name) {
    while (true) {
      int slap;
      std::cout << " You slap the bear!\n 1. Slap\n 2. Run" << std::endl;
      std::cin >> slap;
      if (slap == 1) {
        int random_chance = std::rand() % 100;
        if (random_chance < bear_ratio) {
          std::cout << "You got slapped by the bear and lost 2 points."
                    << std::endl;
          pointObj.accumulatePoints(-2);
        }
        std::cout << "You slap the bear and get 1 point." << std::endl;
        pointObj.accumulatePoints(1);
      } else if (slap == 2) {
        break;
      } else {
        std::cout << "Please re-enter!!!" << std::endl;
      }
    }
  }
  void wolf(std::string name) {
    while (true) {
      int slap;
      std::cout << "You have to slap the wolf!\n 1. Slap\n 2. Run" << std::endl;
      std::cin >> slap;
      if (slap == 1) {
        int random_chance = std::rand() % 100;
        if (random_chance <= wolf_ratio) {
          std::cout << "The wolf bit you. You lost 7 points." << std::endl;
          pointObj.accumulatePoints(-7);
        }
        std::cout << "You slapped the wolf. Plus 2 points." << std::endl;
        pointObj.accumulatePoints(1);
      } else if (slap == 2) {
        break;
      } else {
        std::cout << "Please re-enter!!!" << std::endl;
      }
    }
  }
}; // end class Unit
class Shop {
private:
  const int DOUBLE_POINTS = 100;

public:
  void showShop(Point &pointObj) {
    while (true) {
      int n;
      long long point = pointObj.getPoint();
      std::cout << "--Shop--" << std::endl;
      std::cout << "0. Exit Shop" << std::endl;
      std::cout << "1. Double Points";
      std::cin >> n;
      if (n == 0) {
        break;
      } else if (n == 1) {
        while (true) {
          int c;
          std::cout << "Double Points: " << DOUBLE_POINTS << " point"
                    << std::endl;
          std::cout << "1. Buy, 2. Exit";
          std::cin >> c;
          if (c == 1) {
            if (point >= DOUBLE_POINTS) {
              pointObj.accumulatePoints(-DOUBLE_POINTS);
              pointObj.trueDoublePoint();
            } else {
              std::cout << "You are short " << DOUBLE_POINTS - point << " point"
                        << std::endl;
            }
          } else if (c == 2) {
            break;
          } else {
            std::cout << "Incorrect input, please re-enter!" << std::endl;
            std::cout << "Enter 7689 into the game main menu!!!" << std::endl;
          }
        }
      }
    }
  }
};
class Start {
private:
  Unit bear;
  Unit wolf;
  Shop shop;

public:
  void game() {
    while (true) {
      int c;
      std::cout
          << " 0. Exit the game\n 1. Show point\n 2. Slap Unit\n 3. Show Shop"
          << std::endl;
      std::cin >> c;
      if (c == 2011) {
        pointObj.backdoor();
      } else if (c == 0) { // else if 1
        break;
      } else if (c == 1) { // else if 2
        std::cout << pointObj.getPoint() << std::endl;
      } else if (c == 2) { // else if 3
        while (true) {
          int unit;
          std::cout << "Select the unit you want to slap:\n 0.Exit\n 1.Bear\n "
                       "2. Wolf\n "
                    << std::endl;
          std::cin >> unit;
          if (unit == 0) {
            break;
          } else if (unit == 1) {
            bear.bear("Bear");
          } else if (unit == 2) {
            wolf.wolf("The Wolf");
          }
        } // end while for else if 3
      } else if (c == 3) {
        shop.showShop(pointObj);
      } else if (c == 7689) {
        pointObj.Nightmare();
      } else {
        std::cout << "Please re-enter the number correctly." << std::endl;
      }
    } // end While true Gams
  } // end void game()
}; // end class Start
int main(int argc, char *argv[], char *envp[]) {
  std::srand(std::time(0));
  Start start;
  start.game();
  return 0;
}