#include <cstdlib>
#include <ctime>                      
#include <iostream>
#include <string>
class Point {
private:
  int point = 0;

public:
  void backdoor() {
    int value;
    std::cout << "[DEV MODE ACTIVATED]";
    std::cin >> value;
    point = value;
  }
  int getPoint() { return point; }                        void accumulatePoints(int newPoint) { point += newPoint; }
};
Point pointObj;
class Unit {
private:
  const int bear_ratio = 30;
  const int wolf_ratio = 15;

public:
  void bear(std::string name) {
    while (true) {
      int slap;
      std::cout << " You slap the bear!\n 1. Slap\n 2. Run" << std::endl;
      std::cin >> slap;
      if (slap == 1) {
        int random_chance = std::rand() % 100;
        if (random_chance < bear_ratio) {
          std::cout << "You got slapped by the bear and lost 2 points."
                    << std::endl;
          pointObj.accumulatePoints(-2);
        }
        std::cout << "You slap the bear and get 1 point." << std::endl;
        pointObj.accumulatePoints(1);
      } else if (slap == 2) {
        break;
      } else {
        std::cout << "Please re-enter!!!" << std::endl;
      }
    }
  }
  void wolf(std::string name) {
    while (true) {
      int slap;
      std::cout << "You have to slap the wolf!\n 1. Slap\n 2. Run" << std::endl;
      std::cin >> slap;
      if (slap == 1) {
        int random_chance = std::rand() % 100;
        if (random_chance <= wolf_ratio) {
          std::cout << "The wolf bit you. You lost 7 points." << std::endl;
          pointObj.accumulatePoints(-7);
        }
        std::cout << "You slapped the wolf. Plus 2 points." << std::endl;
        pointObj.accumulatePoints(2);
      } else if (slap == 2) {
        break;
      } else {
        std::cout << "Please re-enter!!!" << std::endl;
      }
    }
  }
};
class Start {
private:
  Unit bear;
  Unit wolf;

public:
  void game() {
    while (true) {
      int c;
      std::cout << " 0. Exit the game\n 1. Show point\n 2. Slap Unit"
                << std::endl;
      std::cin >> c;
      if (c == 2011) {
        pointObj.backdoor();
      } else if (c == 0) { // else if 1
        break;
      } else if (c == 1) { // else if 2
        std::cout << pointObj.getPoint() << std::endl;
      } else if (c == 2) { // else if 3
        while (true) {
          int unit;
          std::cout << "Select the unit you want to slap:\n 0.Exit\n 1.Bear\n "
                       "2. Wolf\n "
                    << std::endl;
          std::cin >> unit;
          if (unit == 0) {
            break;
          } else if (unit == 1) {
            bear.bear("Bear");
          } else if (unit == 2) {
            wolf.wolf("The Wolf");
          }
        } // end while for else if 3
      } else {
        std::cout << "Please re-enter the number correctly." << std::endl;
      }
    } // end While true Gams
  } // end void game()
}; // end class Start
int main(int argc, char *argv[], char *envp[]) {
  std::srand(std::time(0));
  Start start;
  start.game();
  return 0;
}